# QuickNeed Frontend

Frontend-only React/Vite prototype.

## Run
1. Install Node.js.
2. Open this folder in VS Code.
3. Run:
   npm install
   npm run dev

## Demo
Use the landing page buttons to enter Student, Shopkeeper or Admin.

Student:
- Enter: "I forgot my calculator and my exam starts in 20 minutes."
- Request Rahul's free calculator.
- Check My Requests.

Shopkeeper:
- View incoming shop requests after a student reserves a paid item.

Admin:
- View complaints and management screens.

No backend/database is included. All data is mock frontend state.
