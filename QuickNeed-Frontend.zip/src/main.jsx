import React, {useState} from "react";
import { createRoot } from "react-dom/client";
import {
  Search, Clock3, MapPin, ShieldCheck, ArrowRight, LogOut, Plus,
  CheckCircle2, XCircle, Package, MessageSquareWarning, Store,
  Users, Wrench, ChevronRight, Sparkles, CircleDollarSign
} from "lucide-react";
import "./styles.css";

const seed = {
  students: [
    {id:"rahul", name:"Rahul", item:"Scientific Calculator", icon:"🧮", free:true, distance:"3 min", reliability:"98%", available:true},
    {id:"anitha", name:"Anitha", item:"Umbrella", icon:"☂️", free:true, distance:"4 min", reliability:"96%", available:true},
    {id:"karthik", name:"Karthik", item:"Power Bank", icon:"🔋", free:true, distance:"5 min", reliability:"95%", available:true}
  ],
  shops: [
    {id:"stationery", name:"Campus Stationery", item:"Scientific Calculator", price:450, qty:5, distance:"2 min", available:true},
    {id:"essentials", name:"Student Essentials", item:"Power Bank", price:400, qty:2, distance:"4 min", available:true}
  ],
  services: [
    {id:"bike", name:"Campus Bike Service Point", service:"Bike Puncture Repair", price:80, distance:"5 min", available:true},
    {id:"print", name:"Print & Copy Hub", service:"Printing", price:2, distance:"2 min", available:true}
  ]
};

function App(){
  const [role,setRole]=useState(null);
  const [screen,setScreen]=useState("home");
  const [query,setQuery]=useState("");
  const [understood,setUnderstood]=useState(null);
  const [requests,setRequests]=useState([]);
  const [complaints,setComplaints]=useState([]);
  const [lendings,setLendings]=useState([]);
  const [inventory,setInventory]=useState(seed.shops);
  const [students,setStudents]=useState(seed.students);
  const [shops,setShops]=useState(seed.shops);
  const [complaintText,setComplaintText]=useState("");

  const student = role === "student";
  const shop = role === "shop";
  const admin = role === "admin";

  function login(r){setRole(r); setScreen(r==="student"?"dashboard":r==="shop"?"shopdash":"admindash")}
  function logout(){setRole(null);setScreen("home");setUnderstood(null)}

  function analyze(){
    const q=query.toLowerCase();
    let item="Your need", urgency="Medium", deadline="Not specified";
    if(q.includes("calculator")) item="Scientific Calculator";
    else if(q.includes("umbrella") || q.includes("rain")) item="Umbrella";
    else if(q.includes("power bank") || q.includes("charger")) item=q.includes("charger")?"Charger":"Power Bank";
    else if(q.includes("puncture") || q.includes("bike")) item="Bike Puncture Repair";
    else if(q.includes("projector") || q.includes("connect my laptop")) item="HDMI / USB-C Adapter";
    if(q.match(/20\s*min|20\s*minute/)){urgency="High";deadline="20 minutes"}
    else if(q.includes("exam") || q.includes("urgent") || q.includes("now")) urgency="High";
    setUnderstood({item,urgency,deadline,raw:query});
    setScreen("results");
  }

  function addRequest(type, provider, item, price=0){
    const id="REQ-"+String(requests.length+1).padStart(3,"0");
    setRequests(r=>[...r,{id,type,provider,item,price,status:"Requested"}]);
  }

  function updateRequest(id,status){
    setRequests(r=>r.map(x=>x.id===id?{...x,status}:x));
  }

  function addLending(){
    const name=prompt("What item are you willing to lend?");
    if(name) setLendings(l=>[...l,{id:Date.now(),item:name,status:"Available"}]);
  }

  function addInventory(){
    const item=prompt("Item name");
    if(!item)return;
    const price=Number(prompt("Price (₹)")||0);
    setInventory(i=>[...i,{id:Date.now(),name:"My Campus Shop",item,price,qty:1,distance:"2 min",available:true}]);
  }

  function raiseComplaint(){
    if(!complaintText.trim())return;
    setComplaints(c=>[...c,{id:"CMP-"+String(c.length+1).padStart(3,"0"),text:complaintText,status:"Open"}]);
    setComplaintText("");
  }

  const nav = student ? [
    ["dashboard","Find Help"],["requests","My Requests"],["lend","My Lending"],["complaints","Complaints"]
  ] : shop ? [["shopdash","Dashboard"],["inventory","Inventory"],["shoprequests","Requests"]] :
  [["admindash","Dashboard"],["admincomplaints","Complaints"],["users","Users"],["shops","Shops"]];

  if(!role) return <Landing onLogin={login}/>;

  return <div className="app">
    <header className="topbar">
      <div className="brand" onClick={()=>setScreen(nav[0][0])}><span className="brandmark">Q</span><span>QuickNeed</span></div>
      <div className="rolepill">{student?"Student":shop?"Shopkeeper":"Admin"}</div>
      <button className="logout" onClick={logout}><LogOut size={17}/> Logout</button>
    </header>
    <div className="layout">
      <aside className="sidebar">
        <div className="side-title">Workspace</div>
        {nav.map(([id,label])=><button key={id} className={"navbtn "+(screen===id?"active":"")} onClick={()=>setScreen(id)}>{label}<ChevronRight size={16}/></button>)}
      </aside>
      <main className="main">
        {student && <StudentViews {...{screen,setScreen,query,setQuery,analyze,understood,students,shops,requests,addRequest,updateRequest,lendings,addLending,complaints,complaintText,setComplaintText,raiseComplaint}}/>}
        {shop && <ShopViews {...{screen,setScreen,inventory,addInventory,requests,updateRequest}}/>}
        {admin && <AdminViews {...{screen,complaints,setComplaints,students,shops}}/>}
      </main>
    </div>
  </div>
}

function Landing({onLogin}){
  return <div className="landing">
    <div className="landingnav"><div className="brand"><span className="brandmark">Q</span>QuickNeed</div><button className="outlinebtn" onClick={()=>onLogin("student")}>Login</button></div>
    <section className="hero">
      <div className="eyebrow"><Sparkles size={15}/> AI-powered campus assistant</div>
      <h1>When you suddenly need something,<br/><span>find the fastest campus solution.</span></h1>
      <p>Tell QuickNeed what happened. Find a student who can lend it for free, a campus shop where you can buy it, or a campus service that can help.</p>
      <button className="primary big" onClick={()=>onLogin("student")}>Find What I Need <ArrowRight size={19}/></button>
    </section>
    <section className="featuregrid">
      <Feature icon={<Users/>} title="Borrow" text="Get items from fellow students for FREE."/>
      <Feature icon={<Store/>} title="Buy" text="Find campus shops with clear prices and availability."/>
      <Feature icon={<Wrench/>} title="Get Help" text="Find campus services for unexpected situations."/>
    </section>
    <div className="loginrow">
      <span>Demo access:</span>
      <button onClick={()=>onLogin("student")}>Student</button>
      <button onClick={()=>onLogin("shop")}>Shopkeeper</button>
      <button onClick={()=>onLogin("admin")}>Admin</button>
    </div>
  </div>
}
function Feature({icon,title,text}){return <div className="feature"><div className="featureicon">{icon}</div><h3>{title}</h3><p>{text}</p></div>}

function StudentViews(p){
  if(p.screen==="dashboard") return <StudentDash {...p}/>;
  if(p.screen==="results") return <Results {...p}/>;
  if(p.screen==="requests") return <Requests {...p}/>;
  if(p.screen==="lend") return <Lend {...p}/>;
  if(p.screen==="complaints") return <Complaints {...p}/>;
  return null;
}
function StudentDash({query,setQuery,analyze,setScreen,requests}){
  return <div>
    <div className="pagehead"><div><div className="eyebrow">STUDENT ASSISTANT</div><h2>What suddenly happened?</h2><p>Describe your urgent situation in your own words.</p></div></div>
    <div className="searchbox">
      <Sparkles size={21}/>
      <input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==="Enter"&&analyze()} placeholder="I forgot my calculator and my exam starts in 20 minutes."/>
      <button className="primary" onClick={analyze}>Find a Solution <ArrowRight size={17}/></button>
    </div>
    <div className="examples"><span>Try:</span>{["I forgot my calculator","I need an umbrella","My bike has a puncture","I need a laptop adapter"].map(x=><button onClick={()=>setQuery(x)} key={x}>{x}</button>)}</div>
    <div className="sectiontitle"><h3>How QuickNeed helps</h3></div>
    <div className="mini-grid">
      <div className="mini"><span>01</span><h3>Understand</h3><p>Identify the item, urgency and deadline from your description.</p></div>
      <div className="mini"><span>02</span><h3>Search campus</h3><p>Check student lenders, campus shops and services.</p></div>
      <div className="mini"><span>03</span><h3>Act before the deadline</h3><p>Choose the fastest reliable option and request it.</p></div>
    </div>
    <div className="sectiontitle"><h3>Active requests</h3><button onClick={()=>setScreen("requests")}>View all <ArrowRight size={15}/></button></div>
    {requests.length===0?<Empty text="No active requests yet."/>:requests.slice(-2).map(r=><RequestCard key={r.id} r={r}/>)}
  </div>
}
function Results(p){
  const item=p.understood?.item||"Scientific Calculator";
  const isBike=item.toLowerCase().includes("bike");
  const isUmb=item.toLowerCase().includes("umbrella");
  const studentResults=p.students.filter(x=>x.available && (x.item.toLowerCase().includes(item.toLowerCase().split(" ")[0]) || (isUmb&&x.item==="Umbrella") || item==="Your need"));
  const shopResults=p.shops.filter(x=>x.available && (x.item.toLowerCase().includes(item.toLowerCase().split(" ")[0]) || item==="Your need"));
  const services=p.understood && isBike ? [{id:"bike",name:"Campus Bike Service Point",service:"Bike Puncture Repair",price:80,distance:"5 min",available:true}] : [];
  return <div>
    <button className="back" onClick={()=>p.setScreen("dashboard")}>← Back to search</button>
    <div className="pagehead"><div><div className="eyebrow">MATCHING YOUR NEED</div><h2>Best options before your deadline</h2></div></div>
    {p.understood && <div className="understood"><div className="under-title"><Sparkles size={17}/> We understood your need</div><div className="undergrid"><span><b>Item</b>{item}</span><span><b>Urgency</b>{p.understood.urgency}</span><span><b>Deadline</b>{p.understood.deadline}</span></div></div>}
    <div className="sectiontitle"><h3><Users size={19}/> Students — FREE</h3></div>
    {studentResults.length?studentResults.map(x=><div className="provider best" key={x.id}><div className="avatar">{x.name[0]}</div><div className="providerinfo"><div className="tag">BEST MATCH · STUDENT PROVIDER</div><h3>{x.name}</h3><p>{x.icon} {x.item}</p><div className="meta"><span><CircleDollarSign size={15}/> FREE</span><span><Clock3 size={15}/>{x.distance} away</span><span><ShieldCheck size={15}/>{x.reliability} reliable</span></div></div><button className="primary" onClick={()=>p.addRequest("borrow",x.name,x.item,0)}>Request to Borrow</button></div>):<Empty text="No student lender found for this need."/>}
    <div className="sectiontitle"><h3><Store size={19}/> Campus Shops — Paid</h3></div>
    {shopResults.length?shopResults.map(x=><div className="provider" key={x.id}><div className="providericon"><Package/></div><div className="providerinfo"><div className="tag">CAMPUS SHOP</div><h3>{x.name}</h3><p>{x.item}</p><div className="meta"><span className="price">₹{x.price}</span><span>{x.qty} available</span><span><Clock3 size={15}/>{x.distance} away</span></div></div><button className="outlinebtn" onClick={()=>p.addRequest("shop",x.name,x.item,x.price)}>Reserve / Buy</button></div>):null}
    {services.length>0 && <><div className="sectiontitle"><h3><Wrench size={19}/> Campus Services</h3></div>{services.map(x=><div className="provider" key={x.id}><div className="providericon"><Wrench/></div><div className="providerinfo"><div className="tag">CAMPUS SERVICE</div><h3>{x.name}</h3><p>{x.service}</p><div className="meta"><span className="price">₹{x.price}</span><span><Clock3 size={15}/>{x.distance} away</span></div></div><button className="outlinebtn" onClick={()=>p.addRequest("service",x.name,x.service,x.price)}>Request Service</button></div>)}</>}
    <div className="unknown"><Sparkles size={18}/><div><b>Don't know what it's called?</b><p>Describe what the thing does and QuickNeed can suggest an item.</p></div><button className="outlinebtn" onClick={()=>{p.setQuery("I need something that lets me connect my laptop to the projector.");p.setScreen("dashboard")}}>Try resolver</button></div>
  </div>
}
function Requests({requests,updateRequest}){
  return <div><div className="pagehead"><div><div className="eyebrow">TRACKING</div><h2>My Requests</h2><p>Follow every request from sending to completion.</p></div></div>
  {requests.length===0?<Empty text="No requests yet. Try finding something you need."/>:requests.map(r=><div className="requestpanel" key={r.id}><div className="requesttop"><div><span className="requestid">{r.id}</span><h3>{r.item}</h3><p>{r.type==="borrow"?"Borrow from":"Request from"} {r.provider}</p></div><Status status={r.status}/></div><div className="timeline">{["Requested","Accepted","Ready / Handover","Received","Completed"].map((s,i)=><div className={(["Requested","Accepted","Ready / Handover","Received","Completed"].indexOf(r.status)>=i?"done ":"")+"step"} key={s}><span>{i<1?"✓":i+1}</span><small>{s}</small></div>)}</div>{r.status==="Requested"&&<div className="actions"><button className="outlinebtn" onClick={()=>updateRequest(r.id,"Cancelled")}>Cancel</button></div>}{r.status==="Accepted"&&<div className="actions"><button className="primary" onClick={()=>updateRequest(r.id,"Received")}>Mark as Received</button></div>}</div>)}</div>
}
function Lend({lendings,addLending}){return <div><div className="pagehead"><div><div className="eyebrow">SHARE WITH CAMPUS</div><h2>Items I Can Lend</h2><p>Students lend items to other students for FREE.</p></div><button className="primary" onClick={addLending}><Plus size={17}/> Add Item</button></div><div className="notice"><ShieldCheck size={18}/><b>Student lending is always FREE.</b> No selling between student providers.</div>{lendings.length===0?<Empty text="You haven't listed any lending items yet."/>:lendings.map(x=><div className="provider" key={x.id}><div className="providericon"><Package/></div><div className="providerinfo"><h3>{x.item}</h3><p>Available for campus students</p></div><span className="freebadge">FREE</span></div>)}</div>}
function Complaints({complaints,complaintText,setComplaintText,raiseComplaint}){return <div><div className="pagehead"><div><div className="eyebrow">SUPPORT</div><h2>Complaints</h2><p>Report a provider, shop or request issue.</p></div></div><div className="formcard"><h3>Raise a Complaint</h3><textarea value={complaintText} onChange={e=>setComplaintText(e.target.value)} placeholder="Describe what happened..."/><button className="primary" onClick={raiseComplaint}>Submit Complaint</button></div><div className="sectiontitle"><h3>My Complaints</h3></div>{complaints.length===0?<Empty text="No complaints submitted."/>:complaints.map(c=><div className="complaint" key={c.id}><MessageSquareWarning/><div><b>{c.id}</b><p>{c.text}</p></div><Status status={c.status}/></div>)}</div>}
function ShopViews(p){
  if(p.screen==="shopdash") return <div><div className="pagehead"><div><div className="eyebrow">CAMPUS STATIONERY</div><h2>Shop Dashboard</h2><p>Manage inventory and student requests.</p></div></div><div className="stats"><Stat n={p.inventory.length} t="Items"/><Stat n={p.inventory.reduce((a,x)=>a+x.qty,0)} t="Units"/><Stat n={p.requests.filter(x=>x.type==="shop"&&x.status==="Requested").length} t="Pending Requests"/><Stat n="Active" t="Shop Status"/></div><div className="notice"><Store size={18}/><b>Student requests update this dashboard.</b> Accept requests and mark orders ready for pickup.</div></div>;
  if(p.screen==="inventory") return <div><div className="pagehead"><div><div className="eyebrow">STOCK</div><h2>Inventory</h2></div><button className="primary" onClick={p.addInventory}><Plus size={17}/> Add Item</button></div>{p.inventory.map(x=><div className="provider" key={x.id}><div className="providericon"><Package/></div><div className="providerinfo"><h3>{x.item}</h3><p>{x.name}</p><div className="meta"><span className="price">₹{x.price}</span><span>{x.qty} available</span></div></div><span className="available">Available</span></div>)}</div>;
  return <div><div className="pagehead"><div><div className="eyebrow">INCOMING</div><h2>Student Requests</h2></div></div>{p.requests.filter(x=>x.type==="shop").length===0?<Empty text="No shop requests yet. Student requests will appear here."/>:p.requests.filter(x=>x.type==="shop").map(r=><div className="requestpanel" key={r.id}><div className="requesttop"><div><span className="requestid">{r.id}</span><h3>{r.item}</h3><p>Student request · ₹{r.price}</p></div><Status status={r.status}/></div><div className="actions"><button className="primary" onClick={()=>p.updateRequest(r.id,"Accepted")}>Accept</button><button className="outlinebtn" onClick={()=>p.updateRequest(r.id,"Declined")}>Decline</button>{r.status==="Accepted"&&<button className="outlinebtn" onClick={()=>p.updateRequest(r.id,"Ready")}>Mark Ready</button>}</div></div>)}</div>
}
function AdminViews(p){
  if(p.screen==="admindash") return <div><div className="pagehead"><div><div className="eyebrow">ADMIN CONTROL</div><h2>Admin Dashboard</h2><p>Manage complaints, users and campus shops.</p></div></div><div className="stats"><Stat n={p.students.length} t="Student Providers"/><Stat n={p.shops.length} t="Campus Shops"/><Stat n={p.complaints.length} t="Complaints"/><Stat n="Healthy" t="Platform Status"/></div><div className="sectiontitle"><h3>Recent Complaints</h3></div>{p.complaints.length===0?<Empty text="No complaints yet."/>:p.complaints.map(c=><div className="complaint" key={c.id}><MessageSquareWarning/><div><b>{c.id}</b><p>{c.text}</p></div><button className="outlinebtn" onClick={()=>p.setComplaints(cs=>cs.map(x=>x.id===c.id?{...x,status:"Resolved"}:x))}>Resolve</button></div>)}</div>;
  if(p.screen==="admincomplaints") return <div><div className="pagehead"><div><div className="eyebrow">MODERATION</div><h2>Complaints</h2></div></div>{p.complaints.length===0?<Empty text="No complaints to review."/>:p.complaints.map(c=><div className="complaint" key={c.id}><MessageSquareWarning/><div><b>{c.id}</b><p>{c.text}</p></div><Status status={c.status}/><button className="outlinebtn" onClick={()=>p.setComplaints(cs=>cs.map(x=>x.id===c.id?{...x,status:"Resolved"}:x))}>Resolve</button></div>)}</div>;
  if(p.screen==="users") return <div><div className="pagehead"><div><div className="eyebrow">USERS</div><h2>User Management</h2></div></div>{p.students.map(x=><div className="provider" key={x.id}><div className="avatar">{x.name[0]}</div><div className="providerinfo"><h3>{x.name}</h3><p>Student provider · {x.item}</p></div><button className="outlinebtn">Suspend</button></div>)}</div>;
  return <div><div className="pagehead"><div><div className="eyebrow">SHOPS</div><h2>Shop Management</h2></div></div>{p.shops.map(x=><div className="provider" key={x.id}><div className="providericon"><Store/></div><div className="providerinfo"><h3>{x.name}</h3><p>{x.item} · ₹{x.price}</p></div><span className="available">Active</span><button className="outlinebtn">Suspend</button></div>)}</div>
}
function Status({status}){return <span className={"status "+status.toLowerCase().replaceAll(" ","-")}>{status}</span>}
function RequestCard({r}){return <div className="provider"><div className="providericon"><Package/></div><div className="providerinfo"><h3>{r.item}</h3><p>{r.provider}</p></div><Status status={r.status}/></div>}
function Stat({n,t}){return <div className="stat"><strong>{n}</strong><span>{t}</span></div>}
function Empty({text}){return <div className="empty"><Search size={24}/><p>{text}</p></div>}

createRoot(document.getElementById("root")).render(<App/>);
